/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myframe2;
import java.awt.GridLayout;
import javax.swing.*;

/**
 *
 * @author User
 */
public class MyFrame2 extends JFrame{
    
    public MyFrame2(){
        super("My first frame");
        setSize(500,500);
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        GridLayout n1=new GridLayout(2,2,3,3);  /* for grid layout where 2,2 represents rows and coloumns and 3,3 = width*/        
        JLabel label= new JLabel("Name");
        
        JTextField name=new JTextField(10);
        
        JButton button=new JButton("okay");
        JButton button2=new JButton("Cancel");
        JPanel panel=new JPanel();
        
        
        
        
        JLabel txtUsername=new JLabel("Secondary Username");
        JTextField txtUser=new JTextField(10);
        
        
        JLabel jpassword=new JLabel("Unique Password");
        JPasswordField jlblpassword=new JPasswordField(6);
        
        
        panel.setLayout(n1); /* for grid layout */
        
        panel.add(label);
        panel.add(name);
       panel.add(txtUsername);

        panel.add(txtUser);
        
        
      
        
        
        panel.add(jpassword);
        panel.add(jlblpassword);
        
        panel.add(button);
        panel.add(button2);
        
        
        getContentPane().add(panel);
        pack();
        setResizable(true);
        setVisible(true);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        MyFrame2 mf=new MyFrame2();
        
        // TODO code application logic here
    }
    
}
