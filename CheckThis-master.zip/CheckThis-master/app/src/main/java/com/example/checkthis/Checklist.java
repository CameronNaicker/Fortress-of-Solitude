package com.example.checkthis;


import java.util.ArrayList;
import java.util.Date;

public class Checklist {
    private String title;
    private Date dateCreated;
    private ArrayList<Item> items;

    public String getTitle() {
        return title;
    }

    public Checklist(String title, ArrayList<Item> items) {
        this.title = title;
        this.items = items;
    }

    public void setItems(ArrayList<Item> items) {
        this.items = items;
    }

    public Checklist() {
        items = new ArrayList<Item>();
    }


    public void setTitle(String title) {
        this.title = title.trim();
    }

    public void setList(ArrayList<Item> list) {
        this.items = list;
    }

    public void addItem(Item item) {
        items.add(item);
    }

    public void removeItem(int index) {
        items.remove(index);

    }

    public ArrayList<Item> getChecklist() {
        return items;
    }

    @Override
    public String toString() {
        return "Checklist{" +
                "title='" + title + '\'' +
                ", items=" + items +
                '}';
    }
}
