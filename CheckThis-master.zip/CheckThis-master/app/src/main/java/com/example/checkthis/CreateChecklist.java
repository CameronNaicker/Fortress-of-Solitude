package com.example.checkthis;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.auth.User;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;

public class CreateChecklist extends AppCompatActivity implements DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener {

    private ArrayList<Item> items = new ArrayList<>();
    private Checklist creatingChecklist = new Checklist();
    private DatabaseReference dbRef;
    private String title;
    private String saveOrCreate;
    private TextView toolbarTitle;
    private int dueDateClickPosition;
    private Task task;

    RecyclerView recyclerView;
    CreateChecklistAdaptor createChecklistAdaptor;
    Button btnAddItem, btnDone;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_checklist);
        Toolbar toolbar = findViewById(R.id.create_checklist_toolbar);
        toolbarTitle = findViewById(R.id.toolbar_title);
        Typeface honeyScript = Typeface.createFromAsset(this.getApplication().getAssets(), "fonts/HoneyScript-Light.ttf");
        toolbarTitle.setTypeface(honeyScript);
        setSupportActionBar(toolbar);

        buildRecyclerView();
        setButtons();
        Bundle b = this.getIntent().getExtras();
        if (b != null) {
            creatingChecklist.setTitle(b.getString("title"));
            loadChecklist(creatingChecklist.getTitle());
            saveOrCreate = "save";
        } else {
            setTitle();
            saveOrCreate = "create";
        }


        //Adding checklist ArrayList to the database
        //dbRef = FirebaseDatabase.getInstance().getReference().child("Checklists");
        //dbRef.setValue(creatingChecklist);
    }

    private Calendar dueDate;

    @Override
    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
        dueDate = Calendar.getInstance();
        dueDate.set(Calendar.YEAR, year);
        dueDate.set(Calendar.MONTH, month);
        dueDate.set(Calendar.DAY_OF_MONTH, day);
        DialogFragment timePicker = new TimePickerFragment();
        timePicker.show(getSupportFragmentManager(), "time picker");
    }

    @Override
    public void onTimeSet(TimePicker timePicker, int hour, int minute) {

        dueDate.set(Calendar.HOUR_OF_DAY, hour);
        dueDate.set(Calendar.MINUTE, minute);
        setDueDate();
    }

    public void setDueDate() {
        String date;
        if (dueDate.get(Calendar.DAY_OF_MONTH) < 10) {
            date = "0" + dueDate.get(Calendar.DAY_OF_MONTH) + "/" + (dueDate.get(Calendar.MONTH) + 1) + " " + dueDate.get(Calendar.HOUR_OF_DAY) + ":" + dueDate.get(Calendar.MINUTE);
        } else {
            date = dueDate.get(Calendar.DAY_OF_MONTH) + "/" + (dueDate.get(Calendar.MONTH) + 1) + " " + dueDate.get(Calendar.HOUR_OF_DAY) + ":" + dueDate.get(Calendar.MINUTE);
        }

        items.get(dueDateClickPosition).setDueDate(date);
        createChecklistAdaptor.notifyItemChanged(dueDateClickPosition);
    }


    public void setTitle() {
        setTitleDialog();
    }

    public void insertItem() {
        insertItemDialog();
    }

    public void editItem(final int position1) {
        final int position = position1;
        editItemDialog(position);
    }

    public void checkboxClick(final int position, boolean state) {
        dueDateClickPosition = position;
        if (state) {
            DialogFragment datePicker = new DatePickerFragment();
            datePicker.show(getSupportFragmentManager(), "date picker");
        } else {
            items.get(dueDateClickPosition).setDueDate("");
        }
    }

    public void removeItem(int position) {
        items.remove(position);
        createChecklistAdaptor.notifyItemRemoved(position);
        Toast.makeText(this, "Item Removed", Toast.LENGTH_SHORT).show();
    }

    public void buildRecyclerView() {
        recyclerView = findViewById(R.id.create_checklist_recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        createChecklistAdaptor = new CreateChecklistAdaptor(this, getList());
        recyclerView.setAdapter(createChecklistAdaptor);
        createChecklistAdaptor.setOnItemClickListener(new CreateChecklistAdaptor.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
            }

            @Override
            public void onEditClick(int position) {
                editItem(position);
            }

            @Override
            public void onDeleteClick(int position) {
                removeItem(position);
            }

            @Override
            public void checkBoxClicked(int position, boolean state) {
                checkboxClick(position, state);
            }
        });
        ItemTouchHelper helper = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP | ItemTouchHelper.DOWN, 0) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder dragged, @NonNull RecyclerView.ViewHolder target) {

                int position_dragged = dragged.getAdapterPosition();
                int position_target = target.getAdapterPosition();

                Collections.swap(items, position_dragged, position_target);
                createChecklistAdaptor.notifyItemMoved(position_dragged, position_target);

                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {

            }
        });
        helper.attachToRecyclerView(recyclerView);
    }

    public void setButtons() {
        btnAddItem = findViewById(R.id.btnCreateChecklistAddItem);
        btnAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insertItem();
            }
        });
        btnDone = findViewById(R.id.btnCreateChecklistCreate);
        btnDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (items.size() > 0) {
                    doneButtonPressed();
                } else {
                    Toast.makeText(CreateChecklist.this, "The checklist is empty", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private ArrayList<Item> getList() {
        return items;
    }

    private void doneButtonPressed() {
        doneButtonDialog();
    }


    private ProgressDialog progressDialog;

    public void loadChecklist(String title) {
        progressDialog = new ProgressDialog(CreateChecklist.this);
        progressDialog.setMessage("Loading Checklist Data");
        progressDialog.show();
        toolbarTitle.setText(title);
        if (FirebaseAuth.getInstance().getUid() == null) {
            progressDialog.dismiss();
            uidErrorDialog();
        } else {
            dbRef = FirebaseDatabase.getInstance().getReference()
                    .child("Checklists")
                    .child(FirebaseAuth.getInstance().getUid())
                    .child(title);
            dbRef.addChildEventListener(new ChildEventListener() {
                @Override
                public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                    if (dataSnapshot.exists()) {
                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            Item item = snapshot.getValue(Item.class);
                            items.add(item);
                            System.out.println(item.toString().trim());
                        }
                        createChecklistAdaptor.notifyDataSetChanged();
                        progressDialog.dismiss();
                    } else {
                        progressDialog.dismiss();
                        AlertDialog.Builder builder = new AlertDialog.Builder(CreateChecklist.this);
                        builder.setCancelable(false);
                        builder.setTitle("Error");
                        builder.setMessage(task.getException().getMessage());
                        builder.setIcon(R.drawable.alert_dialog_icon);
                        builder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        });
                        builder.show();
                        errorDialog();
                    }
                }

                @Override
                public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                }

                @Override
                public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                }

                @Override
                public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
    }

    private void saveChecklist() {
        creatingChecklist.setList(items);
        dbRef = FirebaseDatabase.getInstance().getReference().child("Checklists");
        //TODO: store each checklist as the checklist title
        //rather than storing it as 'checklist'
        dbRef.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child(creatingChecklist.getTitle()).setValue(creatingChecklist);
        startActivity(new Intent(CreateChecklist.this, MyChecklists.class));
        finish();
    }

    public Dialog errorDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(CreateChecklist.this);
        Dialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        return dialog;
    }

    public Dialog setTitleDialog() {
        final EditText checklistTitle;
        final AlertDialog.Builder builder = new AlertDialog.Builder(CreateChecklist.this);
        LayoutInflater inflater = CreateChecklist.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.checklist_title, null);
        checklistTitle = view.findViewById(R.id.checklistTitleEditText);
        builder.setCancelable(false);
        builder.setView(view);
        builder.setTitle("Create Checklist");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (checklistTitle.getText().toString().trim().isEmpty()) {
                    Toast.makeText(CreateChecklist.this, "Please ensure the checklist has a title.", Toast.LENGTH_LONG).show();
                } else {
                    title = checklistTitle.getText().toString().trim();
                    creatingChecklist.setTitle(title);
                    toolbarTitle.setText(title);
                    insertItem();
                }
            }
        });
        builder.show();
        Dialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        return dialog;
    }

    public Dialog insertItemDialog() {
        final EditText itemTitle, itemDescription;
        final AlertDialog.Builder builder = new AlertDialog.Builder(CreateChecklist.this);

        LayoutInflater inflater = CreateChecklist.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.create_checklist_item_dialog, null);
        itemTitle = view.findViewById(R.id.item_dialog_title);
        itemDescription = view.findViewById(R.id.item_dialog_description);
        builder.setCancelable(false);
        builder.setView(view);
        builder.setTitle("Add Item to Checklist");
        builder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (itemTitle.getText().toString().trim().isEmpty()) {
                    Toast.makeText(CreateChecklist.this, "Please ensure an item is entered.", Toast.LENGTH_LONG).show();
                } else {
                    Item item = new Item(itemTitle.getText().toString());
                    item.setDescription(itemDescription.getText().toString());
                    items.add(item);
                    createChecklistAdaptor.notifyItemInserted(items.size() - 1);
                }
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        builder.show();
        Dialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        return dialog;
    }

    public Dialog editItemDialog(final int position) {
        final EditText itemTitle, itemDescription;
        AlertDialog.Builder builder = new AlertDialog.Builder(CreateChecklist.this);

        LayoutInflater inflater = CreateChecklist.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.create_checklist_item_dialog, null);
        itemTitle = view.findViewById(R.id.item_dialog_title);
        itemDescription = view.findViewById(R.id.item_dialog_description);
        itemTitle.setText(items.get(position).getTitle());
        itemDescription.setText(items.get(position).getDescription());
        builder.setCancelable(false);
        builder.setView(view);
        builder.setTitle("Edit Item");
        builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (itemTitle.getText().toString().trim().isEmpty()) {
                    Toast.makeText(CreateChecklist.this, "Please ensure an item is entered.", Toast.LENGTH_LONG).show();
                } else {
                    items.get(position).setTitle(itemTitle.getText().toString().trim());
                    items.get(position).setDescription(itemDescription.getText().toString().trim());
                    createChecklistAdaptor.notifyItemChanged(position);
                }
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        builder.show();
        Dialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        return dialog;
    }

    public Dialog doneButtonDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setTitle("Create Checklist");
        builder.setMessage("Do you wish to " + saveOrCreate + " this checklist?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                saveChecklist();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        builder.show();
        Dialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        return dialog;
    }

    public Dialog uidErrorDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(CreateChecklist.this);
        builder.setCancelable(false);
        builder.setTitle("Error");
        builder.setMessage("Cannot determine the UID.");
        builder.setIcon(R.drawable.alert_dialog_icon);
        builder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        builder.show();
        Dialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        return dialog;
    }
}