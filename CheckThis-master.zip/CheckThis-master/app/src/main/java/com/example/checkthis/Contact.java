package com.example.checkthis;

public class Contact {
    private String fullName;
    private String email;
    private String uid;

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public Contact(String fullName, String email, String uid) {
        this.fullName = fullName.trim();
        this.email = email.trim();
        this.uid = uid.trim();
    }

    public Contact(User user, String uid) {
        this.fullName = user.getFullName().trim();
        this.email = user.getEmail().trim();
        this.uid = uid.trim();
    }

    @Override
    public String toString() {
        return "Contact{" +
                "fullName='" + fullName + '\'' +
                ", email='" + email + '\'' +
                ", uid='" + uid + '\'' +
                '}';
    }
}
