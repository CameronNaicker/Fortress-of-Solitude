package com.example.checkthis;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class UseChecklist extends AppCompatActivity {

    //TODO: If there's a due date, compare it to the current time & time completed. Highlight text colour accordingly
    //TODO: Notify checklist owner (if checklist is shared) by email that the checklist is finished + details re the checklist
    //TODO: More informative feedback when item is checked off

    private ArrayList<Item> items;
    private String checklistTitle;
    private String checklistPath;
    private int checklistType;
    private int currentItemPosition;
    private TextView toolbarTitle;
    private boolean voiceMode = false;
    private RecyclerView recyclerView;
    private UseChecklistAdaptor useChecklistAdaptor;
    private DatabaseReference dbRef;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_use_checklist);

        items = new ArrayList<>();
        Bundle b = this.getIntent().getExtras();
        if (b != null) {
            checklistTitle = b.getString("title");
            checklistPath = b.getString("path");
        }
        Toolbar toolbar = findViewById(R.id.use_checklist_toolbar);
        toolbarTitle = findViewById(R.id.toolbar_title);
        Typeface honeyScript = Typeface.createFromAsset(this.getApplication().getAssets(), "fonts/HoneyScript-Light.ttf");
        toolbarTitle.setTypeface(honeyScript);
        if (checklistTitle != null) {
            checklistType = 0;
            toolbarTitle.setText(checklistTitle);
            setSupportActionBar(toolbar);
            buildRecyclerView();
            loadData();
        }
        if (checklistPath != null) {
            checklistType = 1;
            toolbarTitle.setText(checklistPath.substring(checklistPath.lastIndexOf("/") + 1));
            setSupportActionBar(toolbar);
            buildRecyclerView();
            loadData(checklistPath);
        }

    }

/*
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.use_checklist_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.use_checklist_menu_voicemode:
                if (voiceMode) {
                    Toast.makeText(this, "Voice Mode Deactivated", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Voice Mode Activated", Toast.LENGTH_SHORT).show();
                }
                voiceMode = !voiceMode;
                break;
        }
        return super.onOptionsItemSelected(item);
    }
    */


    public ArrayList<Item> getList() {
        return items;
    }

    public void itemChecked(final int position, boolean state) {
        int nextPosition = position + 1;
        int previousPosition = position - 1;
        int lastPosition = items.size() - 1;

        if (items.size() == 1) {//if the checklist only has one item, the state can be changed, and the method can be exited.
            items.get(position).setChecked(state);
            updateItem(position, state);
            useChecklistAdaptor.notifyItemChanged(position);
            return;
        }

        try {
            switch (position) {
                case 0:
                    if (!items.get(nextPosition).isChecked()) {//if the item ahead IS NOT checked
                        items.get(position).setChecked(state);
                        updateItem(position, state);
                    } else {                                     //if the item ahead IS checked
                        Toast.makeText(this, "A task ahead is checked: You cannot uncheck this task", Toast.LENGTH_LONG).show();
                        items.get(position).setChecked(!state);
                    }
                    break;
                default:
                    if (position == (items.size() - 1)) { //if the item is the LAST ITEM
                        if (!items.get(previousPosition).isChecked()) {//if the item behind IS NOT checked
                            Toast.makeText(this, "You are skipping a task", Toast.LENGTH_LONG).show();
                            items.get(position).setChecked(!state); //the item is not allowed to be checked, and the state is inverted back.
                        } else { //the previous item is checked - the last item can be checked or unchecked.
                            items.get(position).setChecked(state);
                            updateItem(position, state);
                        }
                    } else { //the item is neither the first nor the last
                        if (items.get(previousPosition).isChecked()) {// if the PREVIOUS item IS CHECKED
                            if (!items.get(nextPosition).isChecked()) {//and the NEXT item IS NOT CHECKED
                                items.get(position).setChecked(state); //then the current item is allowed to be checked
                                updateItem(position, state);
                            } else { //if the NEXT item IS CHECKED
                                items.get(position).setChecked(!state);//the current item cannot change state
                                Toast.makeText(this, "A task ahead is checked: you cannot uncheck this task", Toast.LENGTH_LONG).show();
                            }
                        } else {
                            Toast.makeText(this, "This task cannot be checked: a previous task has not been checked", Toast.LENGTH_LONG).show();
                            items.get(position).setChecked(!state);
                        }
                    }
                    break;
            }

        } catch (Exception e) {
            progressDialog.dismiss();
            AlertDialog.Builder builder = new AlertDialog.Builder(UseChecklist.this);
            builder.setTitle("Error");
            ClassNotFoundException task = new ClassNotFoundException();
            builder.setMessage(e.getMessage());
            builder.setIcon(R.drawable.alert_dialog_icon);
            builder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.cancel();
                }
            });
            builder.show();
        }


        useChecklistAdaptor.notifyItemChanged(position);

    }

    public void buildRecyclerView() {
        recyclerView = findViewById(R.id.use_checklist_recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        useChecklistAdaptor = new UseChecklistAdaptor(this, getList());
        recyclerView.setAdapter(useChecklistAdaptor);
        useChecklistAdaptor.setOnItemClickListener(new UseChecklistAdaptor.OnItemClickListener() {

            @Override
            public void checkBoxClicked(final int position, boolean state) {
                itemChecked(position, state);
            }
        });
    }

    public void loadData() {
        progressDialog = new ProgressDialog(UseChecklist.this);
        progressDialog.setMessage("Loading Checklist Data");
        progressDialog.show();
        if (FirebaseAuth.getInstance().getUid() == null) {
            Toast.makeText(this, "Cannot determine UID", Toast.LENGTH_LONG).show();
        } else {
            dbRef = FirebaseDatabase.getInstance().getReference()
                    .child("Checklists")
                    .child(FirebaseAuth.getInstance().getUid())
                    .child(checklistTitle);
            dbRef.addChildEventListener(new ChildEventListener() {
                @Override
                public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                    if (dataSnapshot.exists()) {
                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            Item item = snapshot.getValue(Item.class);
                            items.add(item);
                            System.out.println(item.toString());
                        }
                        useChecklistAdaptor.notifyDataSetChanged();
                        progressDialog.dismiss();
                    } else {
                        progressDialog.dismiss();
                        AlertDialog.Builder builder = new AlertDialog.Builder(UseChecklist.this);
                        builder.setTitle("Error");
                        ClassNotFoundException task = new ClassNotFoundException();
                        builder.setMessage(task.getException().getMessage());
                        builder.setIcon(R.drawable.alert_dialog_icon);
                        builder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                            }
                        });
                        builder.show();
                    }
                }

                @Override
                public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        Item item = snapshot.getValue(Item.class);
                        System.out.println(snapshot.getKey());
                        int index = Integer.parseInt(snapshot.getKey());
                        items.get(index).setChecked(item.isChecked());
                        items.get(index).setTimeCompleted(item.getTimeCompleted());
                    }
                    useChecklistAdaptor.notifyDataSetChanged();
                }

                @Override
                public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                }

                @Override
                public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
    }

    public void loadData(String path) {
        String uid = path.substring(0, path.indexOf("/"));
        String title = path.substring(path.lastIndexOf("/") + 1);
        checklistTitle = title;
        if (FirebaseAuth.getInstance().getUid() == null) {
            Toast.makeText(this, "Cannot determine UID", Toast.LENGTH_LONG).show();
            progressDialog.dismiss();
            AlertDialog.Builder builder = new AlertDialog.Builder(UseChecklist.this);
            builder.setTitle("Error");
            ClassNotFoundException task = new ClassNotFoundException();
            builder.setMessage("Cannot determine UID.");
            builder.setIcon(R.drawable.alert_dialog_icon);
            builder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.cancel();
                }
            });
            builder.show();
        } else {
            dbRef = FirebaseDatabase.getInstance().getReference("Checklists/" + path);
            dbRef.addChildEventListener(new ChildEventListener() {
                @Override
                public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                    if (dataSnapshot.exists()) {
                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            Item item = snapshot.getValue(Item.class);
                            items.add(item);
                        }
                        useChecklistAdaptor.notifyDataSetChanged();
                    } else {
                        progressDialog.dismiss();
                        AlertDialog.Builder builder = new AlertDialog.Builder(UseChecklist.this);
                        builder.setTitle("Error");
                        ClassNotFoundException task = new ClassNotFoundException();
                        builder.setMessage(task.getException().getMessage());
                        builder.setIcon(R.drawable.alert_dialog_icon);
                        builder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                            }
                        });
                        builder.show();
                    }
                }

                @Override
                public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        Item item = snapshot.getValue(Item.class);
                        System.out.println(snapshot.getKey());
                        int index = Integer.parseInt(snapshot.getKey());
                        items.get(index).setChecked(item.isChecked());
                        items.get(index).setTimeCompleted(item.getTimeCompleted());
                    }
                    useChecklistAdaptor.notifyDataSetChanged();

                }

                @Override
                public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                }

                @Override
                public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
    }

    public void updateItem(int position, boolean state) {
        DatabaseReference updateRef = dbRef;
        updateRef = updateRef.child("checklist").child(position + "");
        updateRef.child("checked").setValue(state);
        updateRef.child("timeCompleted").setValue(items.get(position).getTimeCompleted());
        final MediaPlayer itemClick = MediaPlayer.create(this, R.raw.item_click);
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        itemClick.start();
        vibrator.vibrate(120);
        if (position == items.size() - 1 && state) {
            checklistCompleted();
        }
    }

    public void resetItem(int position, boolean state) {
        items.get(position).setTimeCompleted("");
        DatabaseReference updateRef = dbRef;
        updateRef = updateRef.child("checklist").child(position + "");
        updateRef.child("checked").setValue(state);
        updateRef.child("timeCompleted").setValue(items.get(position).getTimeCompleted());
    }

    public void checklistCompleted() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(UseChecklist.this);
        final LayoutInflater inflater = UseChecklist.this.getLayoutInflater();
        View view = inflater.inflate(R.layout.complete_checklist, null);
        Button goBack = view.findViewById(R.id.btn_goback);
        Button reset = view.findViewById(R.id.btn_reset);
        Button resetReturn = view.findViewById(R.id.btn_reset_and_goback);
        TextView completedTitle = view.findViewById(R.id.complete_checklist_title);
        completedTitle.setText("'" + checklistTitle + "' has been completed!");
        builder.setView(view);
        final AlertDialog dialog = builder.create();
        dialog.show();
        goBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent;
                switch (checklistType) {
                    case 0:
                        intent = new Intent(UseChecklist.this, MyChecklists.class);
                        dialog.dismiss();
                        startActivity(intent);
                        finish();
                        break;
                    case 1:
                        intent = new Intent(UseChecklist.this, SharedChecklists.class);
                        dialog.dismiss();
                        startActivity(intent);
                        finish();
                        break;
                }

            }
        });
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetChecklist();
                dialog.dismiss();
            }
        });
        resetReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetChecklist();
                Intent intent;
                switch (checklistType) {
                    case 0:
                        intent = new Intent(UseChecklist.this, MyChecklists.class);
                        dialog.dismiss();
                        startActivity(intent);
                        finish();
                        break;
                    case 1:
                        intent = new Intent(UseChecklist.this, SharedChecklists.class);
                        dialog.dismiss();
                        startActivity(intent);
                        finish();
                        break;
                }
            }
        });

    }

    public void resetChecklist() {
        for (int i = items.size() - 1; i > -1; i--) {
            resetItem(i, false);
        }
    }


}
