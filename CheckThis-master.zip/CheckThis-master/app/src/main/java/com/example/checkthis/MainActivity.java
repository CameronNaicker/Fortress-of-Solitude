package com.example.checkthis;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {
    private EditText email, password;
    private Button sign_in, login;
    private CheckBox showPass3;
    private TextView forgot_password;
    private FirebaseAuth firebaseAuth;
    private ProgressDialog progressDialog;
    private Task task;
    private Toolbar toolbar;

    //TODO: notify if user has no internet connection - currently will show up as internal error

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar = findViewById(R.id.login_toolbar);
        TextView toolbarTitle = findViewById(R.id.toolbar_title);
        toolbarTitle.setText("Login");
        Typeface honeyScript = Typeface.createFromAsset(this.getApplication().getAssets(), "fonts/HoneyScript-Light.ttf");
        toolbarTitle.setTypeface(honeyScript);
        setSupportActionBar(toolbar);
        TextView welcomeMessage = findViewById(R.id.txt_welcome_message);
        welcomeMessage.setTypeface(honeyScript);

        email = (EditText) findViewById(R.id.txtLoginEmail);
        password = (EditText) findViewById(R.id.passLoginPassword);
        login = (Button) findViewById(R.id.btnLogin);
        sign_in = (Button) findViewById(R.id.signUpBtn);
        forgot_password = (TextView) findViewById(R.id.txtViewForgotPassword);
        showPass3 = findViewById(R.id.showPassword);

        showPass3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    password.setSelection(password.getText().length());
                } else {
                    password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    password.setSelection(password.getText().length());
                }
            }
        });

        firebaseAuth = FirebaseAuth.getInstance();
        progressDialog = new ProgressDialog(this);


        sign_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SignUpActivity.class);
                startActivity(intent);
            }
        });

        forgot_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ForgotPasswordActivity.class);
                startActivity(intent);
            }
        });


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validateCredentials();
            }
        });
    }


    public void validateCredentials() {
        if (email.getText().toString().trim().isEmpty() || password.getText().toString().trim().isEmpty()) {
            progressDialog.dismiss();
            Toast.makeText(this, "Please ensure that none of the fields are empty.", Toast.LENGTH_LONG).show();
        }

        if (!email.getText().toString().trim().isEmpty() && !password.getText().toString().trim().isEmpty()) {
            progressDialog.setMessage("Validating Credentials");
            progressDialog.show();
            final String emailAddress = email.getText().toString().trim();
            final String passwordd = password.getText().toString().trim();


            firebaseAuth.signInWithEmailAndPassword(emailAddress, passwordd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        progressDialog.dismiss();
                        startActivity(new Intent(MainActivity.this, MainMenuActivity.class));
                        finish();
                    } else {
                        progressDialog.dismiss();
                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                        builder.setCancelable(false);
                        builder.setTitle("Error");
                        builder.setMessage(task.getException().getMessage());
                        builder.setIcon(R.drawable.alert_dialog_icon);
                        builder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        });
                        builder.show();
                        errorDialog();
                    }
                }
                //System.out.println(task.getResult());
            });
        }
    }

    public Dialog errorDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        Dialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        return dialog;
    }
}