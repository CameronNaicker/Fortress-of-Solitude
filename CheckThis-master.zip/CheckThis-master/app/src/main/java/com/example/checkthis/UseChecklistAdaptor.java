package com.example.checkthis;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class UseChecklistAdaptor extends RecyclerView.Adapter<UseChecklistHolder> {

    Context c;
    ArrayList<Item> items;
    private UseChecklistAdaptor.OnItemClickListener mListener;


    public UseChecklistAdaptor(Context c, ArrayList<Item> items) {
        this.c = c;
        this.items = items;
    }

    public interface OnItemClickListener {
        void checkBoxClicked(int position, boolean state);
    }


    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    @NonNull
    @Override
    public UseChecklistHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.use_checklist_item, null);

        return new UseChecklistHolder(view, mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull UseChecklistHolder holder, int position) {
        DateFormat df = new SimpleDateFormat("dd/MM HH:mm");
        String nowString = df.format(new Date());
        holder.title.setText(items.get(position).getTitle());
        holder.description.setText(items.get(position).getDescription());
        holder.check.setChecked(items.get(position).isChecked());
        holder.timeCompleted.setText("Time Completed:\t" + items.get(position).getTimeCompleted());
        if (items.get(position).getDueDate().length() > 0) {//if item has a due date
            holder.dueDate.setText("Time Due:\t" + items.get(position).getDueDate());
            if (items.get(position).getTimeCompleted().length() == 0) {//if item is not completed yet
                try {
                    Date now = df.parse(nowString);
                    Date due = df.parse(items.get(position).getDueDate());
                    System.out.println(now.toString());
                    System.out.println(due.toString());
                    if (now.after(due)) {
                        holder.dueDate.setTextColor(Color.RED);
                    } else if (now.before(due)) {
                        holder.dueDate.setTextColor(Color.parseColor("#0085B2"));
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            } else {
                try {
                    Date due = df.parse(items.get(position).getDueDate());
                    Date completed = df.parse(items.get(position).getTimeCompleted());
                    if (due.before(completed)) {
                        holder.dueDate.setTextColor(Color.RED);
                    } else {
                        holder.dueDate.setTextColor(Color.parseColor("#0085B2"));
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        } else {
            holder.dueDate.setText("Time Due:");
            holder.dueDate.setTextColor(Color.parseColor("#0085B2"));
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}
