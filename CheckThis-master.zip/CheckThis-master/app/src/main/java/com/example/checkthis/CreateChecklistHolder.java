package com.example.checkthis;

import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CreateChecklistHolder extends RecyclerView.ViewHolder {

    TextView title, description;
    ImageButton deleteItem, editItem;
    CheckBox hasDueDate;

    public CreateChecklistHolder(@NonNull View itemView, final CreateChecklistAdaptor.OnItemClickListener listener) {
        super(itemView);
        this.title = itemView.findViewById(R.id.tvCreateItemTitle);
        this.description = itemView.findViewById(R.id.tvCreateItemSubtitle);
        this.deleteItem = itemView.findViewById(R.id.btnDeleteCreateItem);
        this.editItem = itemView.findViewById(R.id.btnEditCreateItem);
        this.hasDueDate = itemView.findViewById(R.id.cbxNotifiesCreateItem);

        deleteItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onDeleteClick(position);
                    }
                }
            }
        });

        editItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onEditClick(position);
                    }
                }
            }
        });



        hasDueDate.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.checkBoxClicked(position, hasDueDate.isChecked());
                        if (!b){
                            hasDueDate.setText("Set Due Time?");
                        }
                    }
                }
            }
        });
    }


}
