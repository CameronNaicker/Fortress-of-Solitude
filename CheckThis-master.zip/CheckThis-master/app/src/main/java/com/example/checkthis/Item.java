package com.example.checkthis;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Item {
    private String title;
    private String description;
    private String timeCompleted;
    private String dueDate;
    private boolean isChecked;


    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }


    public Item(String title, String description) {
        this.title = title;
        this.description = description;
    }

    public Item(String title, String description, String timeCompleted, String dueDate, boolean isChecked) {
        this.title = title;
        this.description = description;
        this.timeCompleted = timeCompleted;
        this.dueDate = dueDate;
        this.isChecked = isChecked;
    }

    public Item(String title) {
        this.title = title;
        this.description = "";
        this.timeCompleted = "";
        this.dueDate="";
    }

    public Item() {

    }

    public Item(boolean isChecked, String description, String timeCompleted, String title) {
        this.title = title;
        this.description = description;
        this.timeCompleted = timeCompleted;
        this.isChecked = isChecked;
    }

    @Override
    public String toString() {
        return "Item{" +
                "title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", timeCompleted='" + timeCompleted + '\'' +
                ", isChecked=" + isChecked +
                '}';
    }

    public Item(String title, String description, String timeCompleted, boolean isChecked) {
        this.title = title;
        this.description = description;
        this.timeCompleted = timeCompleted;
        this.isChecked = isChecked;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setTimeCompleted(String timeCompleted) {
        this.timeCompleted = timeCompleted;
    }


    public void setChecked(boolean checked) {
        DateFormat df = new SimpleDateFormat("dd/MM HH:mm");
        isChecked = checked;
        if (checked) {
            if (timeCompleted == "") {
                this.timeCompleted = df.format(new Date());
            }
        } else {
            this.timeCompleted = "";
        }
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getTimeCompleted() {
        return timeCompleted;
    }


    public boolean isChecked() {
        return isChecked;
    }
}
