package com.example.checkthis;


import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.protobuf.DescriptorProtos;

/**
 * A simple {@link Fragment} subclass.
 */
public class SettingFragment extends Fragment {

    private User user;

    private Button change_username, change_password, about_app, log_out;
    private String username, emailAddress;
    private TextView lblUsername, lblEmailAddress;
    private DatabaseReference databaseReference;
    private FirebaseAuth firebaseAuth;
    private FirebaseUser firebaseUser;
    private DatabaseReference dbRef;

    public SettingFragment() {
        // Required empty public constructor
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_setting, container, false);

        final ProgressDialog progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Loading user data");
        progressDialog.show();

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();
        dbRef = FirebaseDatabase.getInstance().getReference("Users");
        dbRef.child(firebaseAuth.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (dataSnapshot.exists()) {
                    user = dataSnapshot.getValue(User.class);
                    loadData();
                    progressDialog.dismiss();
                } else {
                    progressDialog.dismiss();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        Button change_password = (Button) view.findViewById(R.id.btnSettingPassword);
        Button about_app = view.findViewById(R.id.btnSettingAbout);
        Button log_out = (Button) view.findViewById(R.id.btnSettingLogOut);
        lblUsername = view.findViewById(R.id.lblSettingName);
        lblEmailAddress = view.findViewById(R.id.lblSettingEmail);
        lblEmailAddress.setText("");
        lblUsername.setText("");


        assert firebaseUser != null;


        change_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), ChangePasswordActivity.class);
                startActivity(intent);
            }
        });

        about_app.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity(), AboutAndHelpActivity.class));
            }
        });
        log_out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firebaseAuth.getInstance().signOut();
//                Toast.makeText(view.getContext(), "Signing out", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getActivity(), MainActivity.class);
                startActivity(intent);
                getActivity().finish();
            }
        });

        return view;
    }

    public void loadData() {
        if (user != null) {
            lblEmailAddress.setText(user.getEmail().trim());
            lblUsername.setText((user.getFullName()).trim());
        }
    }

}

