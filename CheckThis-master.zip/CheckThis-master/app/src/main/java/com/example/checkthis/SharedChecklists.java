package com.example.checkthis;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class SharedChecklists extends AppCompatActivity {

    private ArrayList<String> sharedChecklists = new ArrayList<>();
    private ArrayList<String> checklistPaths = new ArrayList<>();
    private DatabaseReference dbRef;
    private ProgressDialog progressDialog;
    private TextView toolbarTitle;
    private ArrayAdapter<String> adapter;
    private boolean emptyDialog;

    //TODO: Fix the progressDialog error, the fix I implemented negates the progress dialog completely

    @Override
    public void onBackPressed() {
        startActivity(new Intent(SharedChecklists.this, MainMenuActivity.class));
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shared_checklists);
        ListView listview = (ListView) findViewById(R.id.listSharedChecklists);
        TextView empty = (TextView) findViewById(R.id.shared_checklists_empty);
        listview.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        adapter = new ArrayAdapter<String>(this, R.layout.shared_checklists_list_item, R.id.shared_checklists_itemText, sharedChecklists);

        listview.setAdapter(adapter);

        progressDialog = new ProgressDialog(SharedChecklists.this);
        progressDialog.setMessage("Loading Checklists users have shared with you..");
        progressDialog.show();
        String uid = FirebaseAuth.getInstance().getUid();
        dbRef = FirebaseDatabase.getInstance().getReference("Shared Checklists/" + uid);
        dbRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (!dataSnapshot.exists()){
                    progressDialog.dismiss();
                    toolbarTitle.setText("Checklists Shared with Me (" + sharedChecklists.size() + ")");
                }else{
                    toolbarTitle.setText("Checklists Shared with Me (" + sharedChecklists.size() + ")");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        dbRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        sharedChecklists.add(snapshot.getKey());
                        checklistPaths.add(dataSnapshot.getKey() + "/" + snapshot.getKey());
                        adapter.notifyDataSetChanged();
                    }
                    progressDialog.dismiss();
                } else {
                    progressDialog.dismiss();

                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        Toolbar toolbar = findViewById(R.id.shared_checklists_toolbar);
        toolbarTitle = findViewById(R.id.toolbar_title);
        toolbarTitle.setText("Checklists Shared with Me");
        Typeface honeyScript = Typeface.createFromAsset(this.getApplication().getAssets(), "fonts/HoneyScript-Light.ttf");
        toolbarTitle.setTypeface(honeyScript);
        setSupportActionBar(toolbar);




        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                openSharedChecklist(position);
            }

        });
        empty.setText("No one has shared a checklist with you yet..");
        listview.setEmptyView(empty);

    }

    public void openSharedChecklist(int position) {
        String path = checklistPaths.get(position);
        Intent intent = new Intent(SharedChecklists.this, UseChecklist.class);
        intent.putExtra("path", path);
        startActivity(intent);

    }


}
