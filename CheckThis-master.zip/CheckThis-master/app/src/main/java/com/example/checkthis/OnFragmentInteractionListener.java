package com.example.checkthis;

public interface OnFragmentInteractionListener {
    public void changeFragment(int id);
}