package com.example.checkthis;

import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class UseChecklistHolder extends RecyclerView.ViewHolder {

    TextView title;
    TextView description;
    TextView timeCompleted;
    TextView dueDate;
    CheckBox check;

    public UseChecklistHolder(@NonNull View itemView, final UseChecklistAdaptor.OnItemClickListener listener) {
        super(itemView);
        this.title = itemView.findViewById(R.id.tvUseItemTitle);
        this.description = itemView.findViewById(R.id.tvUseItemDescription);
        this.check = itemView.findViewById(R.id.cbxUseItemCheck);
        this.timeCompleted = itemView.findViewById(R.id.tvUseItemTimeCompleted);
        this.dueDate = itemView.findViewById(R.id.tvUseItemDueTime);


        check.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.checkBoxClicked(position, check.isChecked());
                    }
                }
            }

        });

    }
}
