package com.example.checkthis;

public class User {
    private String fullName;
    String email;

    public User() {
        //default
    }

    public User(String fullName,  String email) {
        this.fullName = fullName.trim();
        this.email = email.trim();
    }

    //Getters
    public String getFullName() {
        return fullName;
    }

    public String getEmail() {
        return email;
    }


    //Setters
    public void setFullName(String fullName) {
        this.fullName = fullName.trim();
    }

    public void setEmail(String email) {
        this.email = email.trim();
    }
}
