package com.example.checkthis;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ChangePasswordActivity extends AppCompatActivity {
    private Button passwordBtn;
    private EditText newPass, confirmNewPass;
    private CheckBox showPass2;
    private FirebaseAuth firebaseAuth;
    private FirebaseUser firebaseUser;
    private Task task;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        passwordBtn = findViewById(R.id.btnChange);
        newPass = findViewById(R.id.passNewPassword);
        confirmNewPass = findViewById(R.id.confirmNewPassword);
        showPass2 = findViewById(R.id.showDiffPass);

        showPass2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    newPass.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    confirmNewPass.setTransformationMethod(HideReturnsTransformationMethod.getInstance());

                    newPass.setSelection(newPass.getText().length());
                    confirmNewPass.setSelection(confirmNewPass.getText().length());
                } else {
                    newPass.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    confirmNewPass.setTransformationMethod(PasswordTransformationMethod.getInstance());

                    newPass.setSelection(newPass.getText().length());
                    confirmNewPass.setSelection(confirmNewPass.getText().length());
                }
            }
        });

        passwordBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changePassword();
            }
        });

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();
    }

    public void changePassword() {
        final ProgressDialog progressDialog = new ProgressDialog(ChangePasswordActivity.this);
        progressDialog.setMessage("Changing password...");
        progressDialog.show();

        if (newPass.getText().toString().trim().equals(confirmNewPass.getText().toString().trim())) {
            firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
            if (firebaseUser != null) {
                firebaseUser.updatePassword(newPass.getText().toString().trim()).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (newPass.length() < 6) {
                            progressDialog.dismiss();
                            AlertDialog.Builder builder = new AlertDialog.Builder(ChangePasswordActivity.this);
                            builder.setCancelable(false);
                            builder.setTitle("Error");
                            builder.setMessage("The password cannot be shorter than 6 characters.");
                            builder.setIcon(R.drawable.alert_dialog_icon);
                            builder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.dismiss();
                                }
                            });
                            builder.show();
                            passwordLengthDialog();
                        } else {
                            if (task.isSuccessful()) {
                                progressDialog.dismiss();
                                Toast.makeText(ChangePasswordActivity.this, "The password has successfully been changed!", Toast.LENGTH_SHORT).show();
//                            Intent intent = new Intent(ChangePasswordActivity.this, SettingFragment.class);
//                            startActivity(intent);
                                newPass.setText("");
                                confirmNewPass.setText("");
                            } else {
                                progressDialog.dismiss();
                                AlertDialog.Builder builder = new AlertDialog.Builder(ChangePasswordActivity.this);
                                builder.setCancelable(false);
                                builder.setTitle("Error");
                                builder.setMessage(task.getException().getMessage());
                                builder.setIcon(R.drawable.alert_dialog_icon);
                                builder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogInterface.dismiss();
                                    }
                                });
                                builder.show();
                                errorDialog();
                            }
                        }
                    }
                });
            }
        } else {
            progressDialog.dismiss();
            Toast.makeText(this, "Please ensure that the passwords match.", Toast.LENGTH_LONG).show();
        }
    }

    public Dialog errorDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(ChangePasswordActivity.this);
        Dialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        return dialog;
    }

    public Dialog passwordLengthDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(ChangePasswordActivity.this);
        Dialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        return dialog;
    }
}