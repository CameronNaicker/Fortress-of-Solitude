package com.example.checkthis;


import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.TooltipCompat;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.tooltip.Tooltip;


/**
 * A simple {@link Fragment} subclass.
 */
public class ChecklistFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_checklist, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        CardView sharedChecklists = view.findViewById(R.id.sharedChecklistsCard);
        CardView myChecklists = view.findViewById(R.id.myChecklistsCard);
        myChecklists.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(view.getContext(), "OPEN MY CHECKLISTS", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(view.getContext(), MyChecklists.class));

            }
        });

        sharedChecklists.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(view.getContext(), "OPEN SHARED CHECKLISTS", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(view.getContext(), SharedChecklists.class));
            }
        });

        FloatingActionButton createChecklist = view.findViewById(R.id.btn_create_checklist);
        Tooltip createChecklistTooltip = new Tooltip.Builder(createChecklist)
                .setText("Create a new checklist")
                .setTextColor(Color.WHITE)
                .setBackgroundColor(Color.parseColor("#8DBCEB"))
                .setGravity(Gravity.START)
                .setDismissOnClick(true).show();
        createChecklist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), CreateChecklist.class);
                startActivity(intent);
            }
        });

        super.onViewCreated(view, savedInstanceState);
    }
}