package com.example.checkthis;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class ForgotPasswordActivity extends AppCompatActivity {
    private EditText emailAddress;
    private Button sendAnEmail;
    private FirebaseAuth firebaseAuth;
    private Task task;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        emailAddress  = (EditText)findViewById(R.id.txtLoginEmail);
        sendAnEmail = (Button) findViewById(R.id.buttonSendEmail);

        firebaseAuth = FirebaseAuth.getInstance();

        //Checks to see if the email address is valid in order to send a reset link.
        sendAnEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firebaseAuth.sendPasswordResetEmail(emailAddress.getText().toString().trim()).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        final ProgressDialog progressDialog = new ProgressDialog(ForgotPasswordActivity.this);

                        if(task.isSuccessful()){
                            Toast.makeText(ForgotPasswordActivity.this, "Password sent to your email address.", Toast.LENGTH_LONG).show();
                        }
                        else{
                            progressDialog.dismiss();
                            AlertDialog.Builder builder = new AlertDialog.Builder(ForgotPasswordActivity.this);
                            builder.setCancelable(false);
                            builder.setTitle("Error");
                            builder.setMessage(task.getException().getMessage());
                            builder.setIcon(R.drawable.alert_dialog_icon);
                            builder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.dismiss();
                                }
                            });
                            builder.show();
                            errorDialog();
                        }
                    }
                });

            }
            });
        }

    public Dialog errorDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(ForgotPasswordActivity.this);
        Dialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        return dialog;
    }
    }