package com.example.checkthis;


import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.KeyListener;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class SearchFragment extends Fragment {

    private ArrayList<Contact> contacts = new ArrayList<>();
    private SearchAdapter adapter;
    private ListView listView;
    private EditText searchField;
    private FirebaseAuth firebaseAuth;
    private DatabaseReference dbRef;
    private TextView searchResult;
    private Button searchButton;
    private View view;


    public SearchFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        this.view = inflater.inflate(R.layout.fragment_search, container, false);
        firebaseAuth = FirebaseAuth.getInstance();
        dbRef = FirebaseDatabase.getInstance().getReference("Users");


        initComponents();


        return this.view;
    }

    public void initComponents() {

        listView = view.findViewById(R.id.contact_search_list);
        adapter = new SearchAdapter(getContext(), R.layout.contact_item, contacts);
        adapter.setItemClickListener(new SearchAdapter.OnItemClickListener() {
            @Override
            public void addContactButtonClicked(int position) {
                addContact(position);
            }
        });
        listView.setAdapter(adapter);

        searchField = view.findViewById(R.id.search_field);
        searchField.requestFocus();
        searchResult = view.findViewById(R.id.contact_search_result_text);
        searchButton = view.findViewById(R.id.search_button);
        InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        inputMethodManager.toggleSoftInput(InputMethodManager.SHOW_IMPLICIT, InputMethodManager.HIDE_IMPLICIT_ONLY);

        searchField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                searchResult.setText("");
            }
        });

        TextView emptyListText = view.findViewById(R.id.contacts_list_empty_text);


        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String searchTerm = searchField.getText().toString();
                if (searchTerm.length() > 0) {
                    doSearch(searchTerm);
                } else {
                    Toast.makeText(getContext(), "Please enter a search term!", Toast.LENGTH_LONG).show();
                }
            }
        });
        listView.setEmptyView(emptyListText);

    }

    public void doSearch(final String term) {
        contacts.clear();
        final ProgressDialog progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Searching..");
        progressDialog.show();

        dbRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        Contact contact = new Contact(snapshot.getValue(User.class), snapshot.getKey());
                        if (contact.getEmail().toLowerCase().startsWith(term.toLowerCase()) || contact.getFullName().toLowerCase().startsWith(term.toLowerCase())) {
                            if (contact.getUid().equals(firebaseAuth.getUid())) {

                            } else {
                                contacts.add(contact);

                            }
                        }
                        adapter.notifyDataSetChanged();
                        String result;
                        if (contacts.size() == 1) {
                            result = contacts.size() + " result found for '" + term + "'";
                        } else {
                            result = contacts.size() + " results found for '" + term + "'";
                        }
                        searchResult.setText(result);
                    }
                    progressDialog.dismiss();
                } else {
                    progressDialog.dismiss();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    public void addContact(final int position) {
        Contact addContact = contacts.get(position);
        DatabaseReference storeContactReference = FirebaseDatabase.getInstance().getReference("UserContacts");
        storeContactReference.child(firebaseAuth.getUid()).child(addContact.getUid()).setValue(addContact).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(getContext(), "Contact Added!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getContext(), task.getResult().toString(), Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}

class SearchAdapter extends ArrayAdapter<Contact> {

    Context context;
    int resource;
    ArrayList<Contact> contacts;
    OnItemClickListener itemClickListener;

    public void setItemClickListener(OnItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    public SearchAdapter(@NonNull Context context, int resource, ArrayList<Contact> contacts) {
        super(context, resource, contacts);
        this.context = context;
        this.resource = resource;
        this.contacts = contacts;
    }

    interface OnItemClickListener {
        void addContactButtonClicked(int position);
    }


    static class ViewHolder {
        TextView fullName;
        TextView email;
        ImageView picture;
        ImageButton addContact;


    }

    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder holder = null;

        if (convertView == null) {
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.contact_item, null);

            holder = new ViewHolder();
            holder.email = (TextView) convertView.findViewById(R.id.contactItem_email);
            holder.fullName = (TextView) convertView.findViewById(R.id.contactItem_fullname);
            holder.picture = (ImageView) convertView.findViewById(R.id.contact_item_picture);
            holder.addContact = convertView.findViewById(R.id.add_contact_button);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.fullName.setText(contacts.get(position).getFullName());
        holder.email.setText(contacts.get(position).getEmail());
        holder.picture.setImageResource(R.mipmap.ic_launcher);
        holder.addContact.setVisibility(View.VISIBLE);
        holder.addContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                itemClickListener.addContactButtonClicked(position);
            }
        });

        return convertView;
    }
}
