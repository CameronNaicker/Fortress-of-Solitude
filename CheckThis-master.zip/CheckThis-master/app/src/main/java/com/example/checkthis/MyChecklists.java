package com.example.checkthis;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MyChecklists extends AppCompatActivity {
    private ArrayList<String> items = new ArrayList<>();
    private ArrayList<Contact> contacts = new ArrayList<>();
    private DatabaseReference dbRef;
    private MyChecklistsAdaptor adapter;
    private ProgressDialog progressDialog;
    private TextView toolbarTitle;
    private boolean emptyDialog;
    private Toolbar toolbar;
    private Task task;

    //TODO: Fix the progressDialog error, the fix I implemented negates the progress dialog completely

    @Override
    public void onBackPressed() {
        startActivity(new Intent(MyChecklists.this, MainMenuActivity.class));
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_checklists);

        final ListView listview = (ListView) findViewById(R.id.listMyChecklists);


        toolbar = findViewById(R.id.my_checklists_toolbar);
        toolbarTitle = findViewById(R.id.toolbar_title);
        toolbarTitle.setText("My Checklists");
        Typeface honeyScript = Typeface.createFromAsset(this.getApplication().getAssets(), "fonts/HoneyScript-Light.ttf");
        toolbarTitle.setTypeface(honeyScript);

        setSupportActionBar(toolbar);
        //getContacts();

        listview.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        adapter = new MyChecklistsAdaptor(this, R.layout.my_checklists_list_item, items);
        adapter.setItemClickListener(new MyChecklistsAdaptor.OnItemClickListener() {
            @Override
            public void editButtonClicked(int position) {
                editChecklist(position);
            }

            @Override
            public void shareButtonClicked(int position) {
                shareChecklist(position);
            }

            @Override
            public void deleteButtonClicked(int position) {
                deleteChecklist(position);
            }

            @Override
            public void titleClicked(int position) {
                openChecklist(position);
            }
        });
        listview.setAdapter(adapter);


        //if the ListView is empty then show a TextView to indicate as such:
        TextView emptyText = (TextView) findViewById(R.id.my_checklists_empty);
        emptyText.setText("You haven't got any checklists yet..");
        listview.setEmptyView(emptyText);


        progressDialog = new ProgressDialog(MyChecklists.this);
        progressDialog.setMessage("Loading Your Checklists");
        progressDialog.show();


        dbRef = FirebaseDatabase.getInstance().getReference("Checklists/" + FirebaseAuth.getInstance().getUid());

        dbRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (!dataSnapshot.exists()) {
                    progressDialog.dismiss();
                    toolbarTitle.setText("My Checklists (" + items.size() + ")");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        dbRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                if (dataSnapshot.exists()) {
                    progressDialog.dismiss();
                    Checklist checklist = dataSnapshot.getValue(Checklist.class);
                    items.add(checklist.getTitle());
                    toolbarTitle.setText("My Checklists (" + items.size() + ")");
                    adapter.notifyDataSetChanged();
                } else {
                    progressDialog.dismiss();
                    android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(MyChecklists.this);
                    builder.setTitle("Error");
                    ClassNotFoundException task = new ClassNotFoundException();
                    builder.setMessage(task.getException().getMessage());
                    builder.setIcon(R.drawable.alert_dialog_icon);
                    builder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.cancel();
                        }
                    });
                    builder.show();
                }
                System.out.println(dataSnapshot.toString());
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        DatabaseReference contactRef = FirebaseDatabase.getInstance().getReference("UserContacts");
        contactRef.child(firebaseAuth.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        Contact contact = new Contact(snapshot.getValue(User.class), snapshot.getKey());
                        contacts.add(contact);

                    }
                } else {
                    progressDialog.dismiss();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }


    public void openChecklist(int position) {
        Intent intent = new Intent(MyChecklists.this, UseChecklist.class);
        intent.putExtra("title", items.get(position));
        startActivity(intent);
    }


    public void deleteChecklist(final int position1) {
        final int position = position1;
        deleteChecklistDialog(position);
    }

    public void getContacts() {
        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        DatabaseReference contactRef = FirebaseDatabase.getInstance().getReference("UserContacts");
        contactRef.child(firebaseAuth.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        Contact contact = new Contact(snapshot.getValue(User.class), snapshot.getKey());
                        contacts.add(contact);
                    }
                } else {
                    progressDialog.dismiss();
                    AlertDialog.Builder builder = new AlertDialog.Builder(MyChecklists.this);
                    builder.setCancelable(false);
                    builder.setTitle("Error");
                    builder.setMessage(task.getException().getMessage());
                    builder.setIcon(R.drawable.alert_dialog_icon);
                    builder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                        }
                    });
                    builder.show();
                    errorDialog();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private String[] pcontacts;//string array of contact names to run parallel to the contacts arraylist

    public void shareChecklist(final int position1) {
        final int position = position1;
        shareChecklistDialog(position);
    }

    public void editChecklist(int position) {
        Intent intent = new Intent(MyChecklists.this, CreateChecklist.class);
        intent.putExtra("title", items.get(position));
        startActivity(intent);
    }

    public Dialog errorDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(MyChecklists.this);
        Dialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        return errorDialog();
    }

    public Dialog deleteChecklistDialog(final int position) {
        final DatabaseReference deleteChecklistRef = FirebaseDatabase.getInstance().getReference()
                .child("Checklists")
                .child(FirebaseAuth.getInstance().getUid())
                .child(items.get(position));

        AlertDialog.Builder builder = new AlertDialog.Builder(MyChecklists.this);
        builder.setTitle("Delete Checklist?");
        builder.setMessage("Are you sure you want to delete '" + items.get(position) + "'?");
        builder.setIcon(R.drawable.alert_dialog_icon);
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                progressDialog.setMessage("Deleting " + items.get(position));
                progressDialog.show();
                items.remove(position);
                toolbarTitle.setText("My Checklists (" + items.size() + ")");
                adapter.notifyDataSetChanged();
                //items.clear();
                deleteChecklistRef.removeValue();
                progressDialog.dismiss();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        builder.show();
        Dialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        return dialog;
    }

    public Dialog shareChecklistDialog(final int position) {
        pcontacts = new String[contacts.size()];
        AlertDialog.Builder builder = new AlertDialog.Builder(MyChecklists.this);
        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(builder.getContext(), android.R.layout.select_dialog_item);
        for (int i = 0; i < pcontacts.length; i++) {
            pcontacts[i] = contacts.get(i).getFullName();
            arrayAdapter.add(pcontacts[i]);
        }

        //LayoutInflater inflater = MyChecklists.this.getLayoutInflater();
        //View view = inflater.inflate(R.layout.share_checklist_select_contact, null);
        builder.setTitle("Share '" + items.get(position) + "' with:");
        builder.setAdapter(arrayAdapter, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                String checklistPath = FirebaseAuth.getInstance().getUid() + "/";
                String selectedContactUid = contacts.get(i).getUid();
                DatabaseReference shareRef = FirebaseDatabase.getInstance().getReference("Shared Checklists/" + selectedContactUid + "/" + checklistPath);
                shareRef.child(items.get(position)).setValue("checklist");
            }
        });
        builder.show();
        Dialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        return dialog;
    }

}

class MyChecklistsAdaptor extends ArrayAdapter<String> {
    ArrayList<String> checklists;
    Context context;
    int resource;
    OnItemClickListener itemClickListener;

    public void setItemClickListener(OnItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    public MyChecklistsAdaptor(@NonNull Context context, int resource, ArrayList<String> checklists) {
        super(context, resource, checklists);
        this.context = context;
        this.resource = resource;
        this.checklists = checklists;
    }

    interface OnItemClickListener {
        void editButtonClicked(int position);

        void shareButtonClicked(int position);

        void deleteButtonClicked(int position);

        void titleClicked(int position);
    }


    static class ViewHolder {
        TextView checklistTitle;
        ImageButton edit;
        ImageButton share;
        ImageButton delete;
    }

    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder holder = null;

        if (convertView == null) {
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.my_checklists_list_item, null);

            holder = new ViewHolder();
            holder.checklistTitle = (TextView) convertView.findViewById(R.id.myChecklists_checklist_name);
            holder.edit = (ImageButton) convertView.findViewById(R.id.my_checklists_edit);
            holder.delete = (ImageButton) convertView.findViewById(R.id.my_checklists_delete);
            holder.share = (ImageButton) convertView.findViewById(R.id.my_checklists_share);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.checklistTitle.setText(checklists.get(position));
        holder.checklistTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                itemClickListener.titleClicked(position);
            }
        });
        holder.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                itemClickListener.editButtonClicked(position);
            }
        });
        holder.share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                itemClickListener.shareButtonClicked(position);
            }
        });
        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                itemClickListener.deleteButtonClicked(position);
            }
        });

        return convertView;
    }
}