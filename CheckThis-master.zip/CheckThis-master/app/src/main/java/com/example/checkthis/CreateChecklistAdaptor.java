package com.example.checkthis;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CreateChecklistAdaptor extends RecyclerView.Adapter<CreateChecklistHolder> {

    Context c;
    ArrayList<Item> items;
    private OnItemClickListener mListener;

    public CreateChecklistAdaptor(Context c, ArrayList<Item> items) {
        this.c = c;
        this.items = items;
    }

    public interface OnItemClickListener {
        void onItemClick(int position);

        void onEditClick(int position);

        void onDeleteClick(int position);

        void checkBoxClicked(int position, boolean state);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }


    @NonNull
    @Override
    public CreateChecklistHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.create_checklist_item, null);

        return new CreateChecklistHolder(view, mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull CreateChecklistHolder holder, int position) {

        holder.title.setText(items.get(position).getTitle());
        holder.description.setText(items.get(position).getDescription());
        if (items.get(position).getDueDate().length() > 1) {
            holder.hasDueDate.setText("Due Time: "+items.get(position).getDueDate());
            holder.hasDueDate.setChecked(true);
        } else {
            holder.hasDueDate.setText("Set Due Time?");
            holder.hasDueDate.setChecked(false);
        }

    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}
