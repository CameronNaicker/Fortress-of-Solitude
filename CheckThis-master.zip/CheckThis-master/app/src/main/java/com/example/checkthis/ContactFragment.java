package com.example.checkthis;


import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class ContactFragment extends Fragment {

    private OnFragmentInteractionListener mListener;

    private ArrayList<Contact> contacts = new ArrayList<>();
    private ContactsAdapters adapter;
    private FirebaseAuth firebaseAuth;
    private DatabaseReference dbRef;
    private FloatingActionButton addContactsButton;
    private TextView emptyListText;
    private ListView listview;


    public ContactFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_contact, container, false);
        final ProgressDialog progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Loading Contacts");
        progressDialog.show();

        listview = rootView.findViewById(R.id.contacts_list);
        emptyListText = rootView.findViewById(R.id.contacts_list_empty_text);
        listview.setEmptyView(emptyListText);

        listview.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        adapter = new ContactsAdapters(getContext(), R.layout.contact_item, contacts);
        listview.setAdapter(adapter);

        firebaseAuth = FirebaseAuth.getInstance();
        dbRef = FirebaseDatabase.getInstance().getReference("UserContacts");
        dbRef.child(firebaseAuth.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        Contact contact = new Contact(snapshot.getValue(User.class), snapshot.getKey());
                        contacts.add(contact);
                        adapter.notifyDataSetChanged();
                        progressDialog.dismiss();
                    }
                } else {
                    emptyListText.setText("You don't have any contacts yet!");
                    progressDialog.dismiss();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        addContactsButton = rootView.findViewById(R.id.btn_add_contact);
        addContactsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.changeFragment(2);
            }
        });
        // Inflate the layout for this fragment
        return rootView;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            mListener = (OnFragmentInteractionListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }


}

class ContactsAdapters extends ArrayAdapter<Contact> {

    Context context;
    int resource;
    ArrayList<Contact> contacts;

    public ContactsAdapters(@NonNull Context context, int resource, ArrayList<Contact> contacts) {
        super(context, resource, contacts);
        this.context = context;
        this.resource = resource;
        this.contacts = contacts;
    }


    static class ViewHolder {
        TextView fullName;
        TextView email;
        ImageView picture;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder holder = null;

        if (convertView == null) {
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.contact_item, null);

            holder = new ViewHolder();
            holder.email = (TextView) convertView.findViewById(R.id.contactItem_email);
            holder.fullName = (TextView) convertView.findViewById(R.id.contactItem_fullname);
            holder.picture = (ImageView) convertView.findViewById(R.id.contact_item_picture);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.fullName.setText(contacts.get(position).getFullName());
        holder.email.setText(contacts.get(position).getEmail());
        holder.picture.setImageResource(R.mipmap.ic_launcher);

        return convertView;
    }
}
