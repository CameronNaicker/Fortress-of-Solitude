package com.example.checkthis;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainMenuActivity extends AppCompatActivity implements OnFragmentInteractionListener {

    private Toolbar toolbar;
    private TextView toolbarTitle;
    private BottomNavigationView navigationView;

    @Override
    public void changeFragment(int id) {
        switch (id) {
            case 0:
                ChecklistFragment checklistFragment = new ChecklistFragment();
                FragmentTransaction checklistFragmentTransaction = getSupportFragmentManager().beginTransaction();
                checklistFragmentTransaction.replace(R.id.frame_layout, checklistFragment);
                navigationView.setSelectedItemId(R.id.checklists);
                checklistFragmentTransaction.commit();
                break;
            case 1:
                //contacts
                break;
            case 2:
                SearchFragment fragment = new SearchFragment();
                FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.frame_layout, fragment);
                navigationView.setSelectedItemId(R.id.search);
                fragmentTransaction.commit();
                //search
                break;
            case 3:
                //profile (settings)
                break;
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
        toolbar = (Toolbar) findViewById(R.id.main_menu_toolbar);
        toolbarTitle = findViewById(R.id.toolbar_title);

        Typeface honeyScript = Typeface.createFromAsset(this.getApplication().getAssets(), "fonts/HoneyScript-Light.ttf");
        toolbarTitle.setTypeface(honeyScript);
        setSupportActionBar(toolbar);
        setSupportActionBar(toolbar);

        navigationView = findViewById(R.id.btm_nav);

        navigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                int id = menuItem.getItemId();


                if (id == R.id.checklists) {
                    menuItem.setChecked(menuItem.isChecked());
                    //create tree fragments
                    ChecklistFragment fragment = new ChecklistFragment();
                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.frame_layout, fragment);
                    toolbarTitle.setText("Checklists");
                    fragmentTransaction.commit();
                }
                //TODO: remove Search Fragment
                if (id == R.id.search) {
                    menuItem.setChecked(menuItem.isChecked());
                    //create tree fragments
                    SearchFragment fragment = new SearchFragment();
                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.frame_layout, fragment);
                    toolbarTitle.setText("Search for new Contacts");
                    //getSupportActionBar().setTitle("Search for new Contacts");
                    fragmentTransaction.commit();
                }

                if (id == R.id.contacts) {
                    menuItem.setChecked(menuItem.isChecked());
                    //create tree fragments
                    ContactFragment fragment = new ContactFragment();
                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.frame_layout, fragment);
                    toolbarTitle.setText("My Contacts");
                    //getSupportActionBar().setTitle("My Contacts");
                    fragmentTransaction.commit();
                }

                if (id == R.id.settings) {
                    menuItem.setChecked(menuItem.isChecked());
                    //create tree fragments
                    SettingFragment fragment = new SettingFragment();
                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.frame_layout, fragment);
                    toolbarTitle.setText("Profile");
                    //getSupportActionBar().setTitle("Profile");
                    fragmentTransaction.commit();
                }
                return false;
            }
        });
        // default fragment is checklists fragment
        navigationView.setSelectedItemId(R.id.checklists);
    }

    @Override
    public void onBackPressed() {
        int currentFragment = navigationView.getSelectedItemId();
        if (currentFragment == R.id.checklists) {
            backButtonHandler();
        }
        if (currentFragment == R.id.contacts) {
            changeFragment(0);
            finish();
        }
        if (currentFragment == R.id.settings) {
            changeFragment(0);
            finish();

        }
        if (currentFragment == R.id.search) {
            changeFragment(0);
            finish();

        }
        return;
    }

    public void backButtonHandler() {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainMenuActivity.this);
        builder.setTitle("Close Application?");
        builder.setMessage("Are you sure you want to close CheckThis?");
        builder.setIcon(R.drawable.alert_dialog_icon);
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finishAffinity();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        builder.show();
    }
}
