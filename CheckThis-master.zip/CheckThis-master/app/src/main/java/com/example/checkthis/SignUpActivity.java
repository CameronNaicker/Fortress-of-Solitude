package com.example.checkthis;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.KeyListener;
import android.text.method.PasswordTransformationMethod;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignUpActivity extends AppCompatActivity {
    private EditText txtFullName, txtEmail, passPassword, passConfirmPassword;
    private CheckBox showPass;
    private Button btnSignUp;
    private FirebaseAuth firebaseAuth;
    private DatabaseReference ref;
    private String fullName, email, password;
    private Toolbar toolbar;
    private Task task;

    //TODO: disable back button returning user to sign in page.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        toolbar = findViewById(R.id.sign_up_toolbar);
        TextView toolbarTitle = findViewById(R.id.toolbar_title);
        toolbarTitle.setText("Sign Up");
        Typeface honeyScript = Typeface.createFromAsset(this.getApplication().getAssets(), "fonts/HoneyScript-Light.ttf");
        toolbarTitle.setTypeface(honeyScript);
        setSupportActionBar(toolbar);
        setButtons();

        txtEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(validateEmail(txtEmail.getText().toString())){
                    txtEmail.setTextColor(Color.parseColor("#00B34D"));
                }else{
                    txtEmail.setTextColor(Color.RED);

                }
            }
        });
        firebaseAuth = FirebaseAuth.getInstance();

        showPass.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b){
                    passPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    passConfirmPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());

                    passPassword.setSelection(passPassword.getText().length());
                    passConfirmPassword.setSelection(passConfirmPassword.getText().length());
                } else {
                    passPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    passConfirmPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());

                    passPassword.setSelection(passPassword.getText().length());
                    passConfirmPassword.setSelection(passConfirmPassword.getText().length());
                }
            }
        });

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                captureDetails();
            }
        });
    }

    public boolean validateEmail(String email) {
        String EMAIL_REGEX = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
        return email.matches(EMAIL_REGEX);
    }

    public boolean validate() {

        if (!(txtEmail.getText().toString().trim().isEmpty() || txtFullName.getText().toString().trim().isEmpty() || passPassword.getText().toString().trim().isEmpty() || passPassword.getText().toString().trim().isEmpty())) {
            if (!validateEmail(txtEmail.getText().toString().trim())) {
                Toast.makeText(this, "Please ensure that you use a valid Email Address.", Toast.LENGTH_LONG).show();
            } else {
                if (passPassword.getText().toString().trim().equals(passConfirmPassword.getText().toString().trim())) {
                    if(passPassword.getText().toString().trim().length() < 6){
                        Toast.makeText(this, "Please ensure your password is more than 6 characters in length.", Toast.LENGTH_LONG).show();
                    }
                    else{
                        return true;
                    }
                } else {
                    Toast.makeText(this, "Please ensure that the passwords match.", Toast.LENGTH_LONG).show();
                }
            }
        } else {
            Toast.makeText(this, "Please ensure that none of the fields are empty.", Toast.LENGTH_LONG).show();
        }
        return false;
    }

    public void captureDetails() {
        fullName = (txtFullName.getText().toString());
        email = (txtEmail.getText().toString().trim());

        if (validate()) {
            final ProgressDialog progressDialog = new ProgressDialog(SignUpActivity.this);
            progressDialog.setMessage("Working...");
            progressDialog.show();
            password = passPassword.getText().toString().trim();


            firebaseAuth.createUserWithEmailAndPassword(email.trim(), password.trim()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        task.getResult().getUser().getUid();
                        ref = FirebaseDatabase.getInstance().getReference("Users");

                        User newUser = new User();

                        newUser.setFullName(fullName.trim());
                        newUser.setEmail(email.trim());

                        //The user reference is creating a child branch in the users path for the individual user, which is uniquely
                        //identifiable by the UID, which is generated using the Authentication with Firebase
                        ref.child(task.getResult().getUser().getUid()).setValue(newUser);
                        progressDialog.dismiss();

                        Toast.makeText(SignUpActivity.this, "Sign up Successful!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(SignUpActivity.this, MainActivity.class));
                    } else {
                        progressDialog.dismiss();
                        AlertDialog.Builder builder = new AlertDialog.Builder(SignUpActivity.this);
                        builder.setCancelable(false);
                        builder.setTitle("Error");
                        builder.setMessage(task.getException().getMessage());
                        builder.setIcon(R.drawable.alert_dialog_icon);
                        builder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        });
                        builder.show();
                        errorDialog();
                    }
                }
            });
        }
    }

    public void setButtons() {
        txtFullName = findViewById(R.id.txtFullName);
        txtEmail = findViewById(R.id.txtEmail);
        passPassword = findViewById(R.id.passPassword);
        passConfirmPassword = findViewById(R.id.passConfirmPasword);
        btnSignUp = findViewById(R.id.btnSignUp);
        showPass = findViewById(R.id.passwordShowDiff);
    }

    public Dialog errorDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(SignUpActivity.this);
        Dialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        return dialog;
    }
}